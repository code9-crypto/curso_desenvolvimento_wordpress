<?php

dynamic_sidebar( 'footer-bar-col-1-sidebar' );
