<?php

dynamic_sidebar( 'footer-bar-col-2-sidebar' );
