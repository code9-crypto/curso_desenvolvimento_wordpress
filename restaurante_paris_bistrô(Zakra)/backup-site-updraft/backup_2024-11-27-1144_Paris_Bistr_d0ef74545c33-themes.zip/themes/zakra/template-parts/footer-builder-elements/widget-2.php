<?php

dynamic_sidebar( 'footer-sidebar-2' );
