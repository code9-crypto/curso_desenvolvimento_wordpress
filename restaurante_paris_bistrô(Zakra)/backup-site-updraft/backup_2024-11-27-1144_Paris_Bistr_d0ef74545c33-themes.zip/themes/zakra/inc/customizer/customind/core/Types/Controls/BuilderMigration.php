<?php
/**
 * Builder Migration class.
 */

namespace Customind\Core\Types\Controls;

/**
 * Text control class.
 */
class BuilderMigration extends AbstractControl {

	/**
	 * {@inheritDoc}
	 */
	public $type = 'customind-builder-migration';
}
