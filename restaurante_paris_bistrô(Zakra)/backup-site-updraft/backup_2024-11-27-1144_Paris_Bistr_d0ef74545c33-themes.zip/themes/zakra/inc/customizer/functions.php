<?php
/** @return \Customind\Core\Customind */
function zakra_customind( ) {
	global $customind;
	return $customind;
}
